import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import GUI from "lil-gui";
// Import from the correct examples folder in Three.js
import { FontLoader } from "three/examples/jsm/loaders/FontLoader.js";
import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry.js";

/**
 * Base
 */
// Debug
const gui = new GUI();

// Canvas
const canvas = document.querySelector("canvas.webgl");

// Scene
const scene = new THREE.Scene();

/**
 * Textures
 */
const textureLoader = new THREE.TextureLoader();

// Font
const fontLoader = new FontLoader();
fontLoader.load("https://threejs.org/examples/fonts/helvetiker_regular.typeface.json", (font) => {
  const textGeo = new TextGeometry("Mr Coder", {
    font: font,  // Use the loaded font
    size: 0.5,
    height: 0.2,
    curveSegments: 7,
    bevelEnabled: true,
    bevelThickness: 0.3,
    bevelSize: 0.02,
    bevelOffset: 0,
    bevelSegments: 5,
  });

  const textMaterial = new THREE.MeshNormalMaterial();
  // textMaterial.wireframe = true  
  const text = new THREE.Mesh(textGeo, textMaterial);
  // textGeo.computeBoundingBox();
  // textGeo.translate(
  //   -(textGeo.boundingBox.max.x - 0.02) * 0.5,
  //   -(textGeo.boundingBox.max.y - 0.02) * 0.5,
  //   -(textGeo.boundingBox.max.z - 0.3) * 0.5
  // )
  // text.position.x = -1
  textGeo.center()
  scene.add(text);
});


// Heart Object
for (let i = 0; i < 100; i++) {
  const heartX = -25;
  const heartY = -25;
  const heartShape = new THREE.Shape();
  heartShape.moveTo(25 + heartX, 25 + heartY);
  heartShape.bezierCurveTo(25 + heartX, 25 + heartY, 20 + heartX, 0 + heartY, 0 + heartX, 0 + heartY);
  heartShape.bezierCurveTo(-30 + heartX, 0 + heartY, -30 + heartX, 35 + heartY, -30 + heartX, 35 + heartY);
  heartShape.bezierCurveTo(-30 + heartX, 55 + heartY, -10 + heartX, 77 + heartY, 25 + heartX, 95 + heartY);
  heartShape.bezierCurveTo(60 + heartX, 77 + heartY, 80 + heartX, 55 + heartY, 80 + heartX, 35 + heartY);
  heartShape.bezierCurveTo(80 + heartX, 35 + heartY, 80 + heartX, 0 + heartY, 50 + heartX, 0 + heartY);
  heartShape.bezierCurveTo(35 + heartX, 0 + heartY, 25 + heartX, 25 + heartY, 25 + heartX, 25 + heartY);

  const extrudeSettings = {
    depth: 8,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 2,
    bevelSize: 1,
    bevelThickness: 1,
  };

  const materialRed = new THREE.MeshNormalMaterial({
    color: 0xffffff,
  });

  const geometryHeart = new THREE.ExtrudeGeometry(heartShape, extrudeSettings);
  const meshHeart = new THREE.Mesh(geometryHeart, materialRed);
  meshHeart.rotation.x = Math.PI
  meshHeart.position.x = (Math.random() - 0.5) * 20;
  meshHeart.position.y = (Math.random() - 0.5) * 20;
  meshHeart.position.z = (Math.random() - 0.5) * 20;
  meshHeart.scale.set(0.01, 0.01, 0.01);

  scene.add(meshHeart);
}
/**
 * Sizes
 */
const sizes = {
  width: window.innerWidth,
  height: window.innerHeight,
};

/**
 * Camera
 */
// Base camera
const camera = new THREE.PerspectiveCamera(
  75,
  sizes.width / sizes.height,
  0.1,
  100
);
camera.position.x = 1;
camera.position.y = 1;
camera.position.z = 2;
scene.add(camera);

// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;

/**
 * Renderer
 */
const renderer = new THREE.WebGLRenderer({
  canvas: canvas,
});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

/**
 * Animate
 */
const clock = new THREE.Clock();

const tick = () => {
  const elapsedTime = clock.getElapsedTime();

  // Update controls
  controls.update();

  // Render
  renderer.render(scene, camera);

  // Call tick again on the next frame
  window.requestAnimationFrame(tick);
};

tick();
